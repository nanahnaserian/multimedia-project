// Firebase configuration
const firebaseConfig = {
    apiKey: "YOUR_API_KEY",
    authDomain: "YOUR_AUTH_DOMAIN",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_STORAGE_BUCKET",
    messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Firebase UI configuration for OAuth providers
const uiConfig = {
    signInSuccessUrl: '/',
    signInOptions: [
        firebase.auth.GoogleAuthProvider.PROVIDER_ID,
        firebase.auth.FacebookAuthProvider.PROVIDER_ID,
        firebase.auth.TwitterAuthProvider.PROVIDER_ID
    ]
};

// Initialize Firebase UI
const ui = new firebaseui.auth.AuthUI(firebase.auth());

// Function to handle Google sign-in
function signInWithGoogle() {
    firebase.auth().signInWithPopup(new firebase.auth.GoogleAuthProvider());
}

// Function to handle Facebook sign-in
function signInWithFacebook() {
    firebase.auth().signInWithPopup(new firebase.auth.FacebookAuthProvider());
}

// Function to handle Twitter sign-in
function signInWithTwitter() {
    firebase.auth().signInWithPopup(new firebase.auth.TwitterAuthProvider());
}

// Function to check user authentication state
firebase.auth().onAuthStateChanged(function(user) {
    if (user) {
        // User is signed in
        // You can redirect to the main page or perform other actions here
        console.log('User is signed in:', user);
    } else {
        // User is signed out
        // You can show the login form or perform other actions here
        console.log('User is signed out');
    }
});

// Start Firebase UI OAuth flow
ui.start('.login-form-container', uiConfig);
