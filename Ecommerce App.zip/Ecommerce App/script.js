let cart = [];
let total = 0;

function addToCart(productName, productPrice) {
    cart.push({ name: productName, price: productPrice });
    total += productPrice;
    updateCart();
}

function updateCart() {
    let cartItemsElement = document.getElementById("cart-items");
    let cartTotalElement = document.getElementById("cart-total");

    cartItemsElement.innerHTML = "";
    cart.forEach(item => {
        let listItem = document.createElement("li");
        listItem.textContent = item.name + ": " + item.price + "ksh";
        cartItemsElement.appendChild(listItem);
    });

    cartTotalElement.textContent = total;
}

// JavaScript code

// Function to add items to the cart
function addToCart(productName, price) {
    // Add the selected item to the cart
    var cartItems = document.getElementById("cart-items");
    var listItem = document.createElement("li");
    listItem.textContent = productName + ": " + price + " ksh";
    cartItems.appendChild(listItem);
    
    // Update the total price
    var cartTotal = document.getElementById("cart-total");
    var currentTotal = parseInt(cartTotal.textContent);
    currentTotal += price;
    cartTotal.textContent = currentTotal;
}

// Function to extract product names and prices and create a list
function extractProducts() {
    // Electronics
    var electronicProducts = document.querySelectorAll(".mySlides .product-name");
    var electronicPrices = document.querySelectorAll(".mySlides button");
    for (var i = 0; i < electronicProducts.length; i++) {
        var productName = electronicProducts[i].textContent;
        var price = parseInt(electronicPrices[i].getAttribute("onclick").match(/\d+/)[0]);
        addToCart(productName, price);
    }

    // Clothes
    var clothesProducts = document.querySelectorAll(".mySlides .product-name");
    var clothesPrices = document.querySelectorAll(".mySlides button");
    for (var i = 0; i < clothesProducts.length; i++) {
        var productName = clothesProducts[i].textContent;
        var price = parseInt(clothesPrices[i].getAttribute("onclick").match(/\d+/)[0]);
        addToCart(productName, price);
    }
}



